<template>
  <div id="footer">
    <a-row class="footerLine">
      <a-col :span="12">
        <a-row class="title">支持与服务</a-row>
        <a-row class="li">帮助文档</a-row>
        <a-row class="li">提交建议</a-row>
        <a-row class="li">联系邮箱：pub_jryzt_jgswyh@pingan.com.cn</a-row>
        <a-row class="li"
          >联系地址：中国 - 上海 徐汇区宛平南路 1119 号保利西岸A座
          (200230)</a-row
        >
        <a-row class="li"
          >版权所有 © 上海壹账通金融科技有限公司
          未经许可不得复制、转载或摘编，违者必究</a-row
        >
      </a-col>
      <a-col :span="12" style="text-align: left;">
        <a-row class="title">关注科技中心云</a-row>
        <a-row class="li">快乐平安公众号</a-row>
        <a-row class="li"
          ><img
            width="90"
            src="../../assets/images/qrcode.jpg"
            alt="qrcode"
        /></a-row>
      </a-col>
    </a-row>
    <a
      class="beianbeian"
      target="_blank"
      href="http://www.beianbeian.com/beianxinxi/d07a8dbf-90fb-4e3c-905d-443333c92b15.html"
      >粤ICP备06118290号</a
    >
  </div>
</template>

<script>
export default {}
</script>

<style lang="less" scoped>
@import '../../assets/css/baseVar.less';
#footer {
  position: relative;
  background-color: #000;
  margin: 0 auto;
  padding: 20px 20px;
  color: #fff;
  font-size: 14px;
  .title {
    font-size: 18px;
    font-weight: bold;
  }
  .li {
    line-height: 1.8;
  }
  .beianbeian {
    position: absolute;
    right: 0px;
    bottom: 0px;
  }
}
</style>
