import BasicLayout from './BasicLayout'

export { BasicLayout }
