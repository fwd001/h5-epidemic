const maxDate = '20361231235959000+08:00'
const showDateFormat = 'YYYY-MM-DD HH:mm:ss'
const timeZoneDate = 'YYYYMMDDHHmmssSSSZ'

export { maxDate, showDateFormat, timeZoneDate }
