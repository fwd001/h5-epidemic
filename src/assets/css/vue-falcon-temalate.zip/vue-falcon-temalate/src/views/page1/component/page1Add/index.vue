<template>
  <div id="page1-add">
    页面1 新增
  </div>
</template>

<script>
export default {
  components: {}
}
</script>

<style></style>
