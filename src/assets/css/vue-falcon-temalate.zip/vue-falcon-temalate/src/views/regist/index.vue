<template>
  <div>
    注册
    <router-link to="/login">
      登陆
    </router-link>
  </div>
</template>

<script>
export default {}
</script>

<style></style>
