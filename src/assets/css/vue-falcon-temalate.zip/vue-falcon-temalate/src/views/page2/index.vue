<template src="./template.html" />
<script src="./script.js"></script>
<style lang='less' src='./style.less'></style>
