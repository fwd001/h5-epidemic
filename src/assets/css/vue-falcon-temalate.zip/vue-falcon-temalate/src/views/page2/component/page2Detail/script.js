import moment from 'moment'

export default {
  data() {
    return {
      lgspan_r: 18,
      lgspan_l: 6,
      detailData: {},
      moment
      // showDateFormat
    }
  },
  components: {
  },
  props: {},

  created() {},
  methods: {}
}
